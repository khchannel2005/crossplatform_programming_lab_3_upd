pluginManagement {
    repositories {
        mavenCentral()
        gradlePluginPortal()
    }
}
