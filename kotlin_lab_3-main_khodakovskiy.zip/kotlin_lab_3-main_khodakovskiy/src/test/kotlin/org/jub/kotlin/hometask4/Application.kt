package org.jub.kotlin.hometask4

import java.io.File
import java.util.concurrent.Callable
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class Application(
    private val resultsFile: String,
    private val tasks: List<Callable<Int>>
) {
    private val executor: ExecutorService = Executors.newFixedThreadPool(10) // Пул з 10 потоків

    companion object {
        fun create(resultsFile: String, tasks: List<Callable<Int>>): Application {
            return Application(resultsFile, tasks)
        }
    }

    fun run() {
        val input = generateSequence { readLine() }
        input.forEach { command ->
            when {
                command == "help" -> {
                    println("Available commands: task <index>")
                }
                command.startsWith("task") -> {
                    val parts = command.split(" ")
                    if (parts.size == 2 && parts[1].toIntOrNull() != null) {
                        val taskIndex = parts[1].toInt()
                        if (taskIndex in tasks.indices) {
                            executeTask(taskIndex)
                        }
                    }
                }
                else -> {
                    println("Invalid command")
                }
            }
        }
    }

    private fun executeTask(index: Int) {
        executor.submit {
            try {
                val result = tasks[index].call() // Виконання задачі
                synchronized(File(resultsFile)) {
                    File(resultsFile).appendText("$result\n") // Запис результату в файл
                }
            } catch (e: Exception) {
                println("Error executing task $index: ${e.message}")
            }
        }
    }

    fun waitToFinish() {
        executor.shutdown()
        executor.awaitTermination(1, TimeUnit.MINUTES) // Очікуємо завершення всіх задач
    }
}
