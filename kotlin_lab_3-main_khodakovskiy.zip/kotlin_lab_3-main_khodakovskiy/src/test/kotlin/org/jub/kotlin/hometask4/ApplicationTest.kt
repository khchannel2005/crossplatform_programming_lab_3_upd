package org.jub.kotlin.hometask4

import org.junit.jupiter.api.*
import java.io.*
import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.nio.file.Path
import java.util.concurrent.Callable
import java.util.concurrent.TimeUnit
import kotlin.test.assertEquals
import kotlin.test.assertTrue

internal object ApplicationTest {

    private lateinit var resultsFile: Path
    private var baos: ByteArrayOutputStream = ByteArrayOutputStream()

    private val tasks = listOf(
        Callable {
            println("Task started on thread ${Thread.currentThread().name}") // Вивести на якому потоці виконується задача
            Thread.sleep(100) // Імітація затримки
            1
        },
        Callable {
            println("Task started on thread ${Thread.currentThread().name}")
            Thread.sleep(200)
            2
        },
        Callable {
            println("Task started on thread ${Thread.currentThread().name}")
            Thread.sleep(300)
            3
        }
    )

    @JvmStatic
    @BeforeAll
    fun setUpStatic() {
        baos = ByteArrayOutputStream()
        System.setOut(PrintStream(baos, true, StandardCharsets.UTF_8))
    }

    @BeforeEach
    fun setUp() {
        resultsFile = Files.createTempFile("results", ".txt")
        Files.writeString(resultsFile, "") // Очищаємо файл перед кожним тестом
    }

    @AfterEach
    fun tearDown() {
        System.setOut(System.out)
        System.setIn(System.`in`)
        Files.deleteIfExists(resultsFile) // Видалення тимчасового файлу після тесту
    }

    private fun setSystemIn(input: String) {
        System.setIn(input.byteInputStream(StandardCharsets.UTF_8)) // Перенаправлення вводу для тестів
    }

    private fun List<String>.toInput() = joinToString(System.lineSeparator()) // Перетворення списку команд в формат вводу

    @Test
    @Timeout(value = 20, unit = TimeUnit.SECONDS)
    fun limitThreads() {
        val tasks = List(7) {
            Callable {
                Thread.sleep(1000) // Кожна задача займає 1 секунду
                42
            }
        }

        val app = Application.create(resultsFile.toString(), tasks)

        val commands = List(7) { "task $it" } // Створення 7 команд для виконання
        setSystemIn(commands.toInput()) // Перенаправлення вводу в тест

        val startTime = System.currentTimeMillis() // Час початку виконання
        app.run() // Запуск додатку для виконання задач

        val maxWaitTime = 7000L  // Очікування 7 секунд
        var elapsedTime = 0L

        while (elapsedTime < maxWaitTime) {
            val outputs = Files.readAllLines(resultsFile).size // Кількість виконаних задач
            if (outputs >= 6) {
                break
            }
            Thread.sleep(500)  // Чекаємо 500 мс між перевірками
            elapsedTime = System.currentTimeMillis() - startTime
        }

        val endTime = System.currentTimeMillis() // Час завершення виконання
        val outputs = Files.readAllLines(resultsFile).size // Кількість виконаних задач

        println("Elapsed time: ${endTime - startTime} ms")

        // Перевірка, що не більше 6 задач виконано за 7 секунд
        assertTrue(outputs <= 6, "You cannot finish 6+ tasks 1 sec each in 7 secs")
        assertTrue(outputs >= 2, "It looks like tasks are not performed in parallel") // Перевірка паралельного виконання

        app.waitToFinish() // Очікування завершення всіх задач
    }





    @Test
    fun testHelpCommand() {
        val commands = listOf("help")
        setSystemIn(commands.toInput())

        val app = Application.create(resultsFile.toString(), tasks)
        app.run()

        val output = baos.toString(StandardCharsets.UTF_8)
        assertTrue(output.contains("Available commands"), "Help message is incorrect")
    }

    @Test
    fun testTaskExecution() {
        val tasks = listOf(Callable { 42 })
        val app = Application.create(resultsFile.toString(), tasks)

        val commands = listOf("task 0")
        setSystemIn(commands.toInput())

        app.run()

        // Дочекаємося завершення всіх завдань
        app.waitToFinish()

        val resultContent = Files.readString(resultsFile)
        assertEquals("42\n", resultContent, "Task result is incorrect")
    }


    @Test
    fun testInvalidCommand() {
        val commands = listOf("unknown")
        setSystemIn(commands.toInput())

        val app = Application.create(resultsFile.toString(), tasks)
        app.run()

        val output = baos.toString(StandardCharsets.UTF_8)
        assertTrue(output.contains("Invalid command"), "Unknown command handling is incorrect")
    }
}
